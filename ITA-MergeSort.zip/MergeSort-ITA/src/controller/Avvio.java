package controller;

import java.util.Scanner;

public class Avvio {

	public static void main(String[] args) {

		Utility u= new Utility();
		Scanner input= new Scanner(System.in);
		boolean flag;
		int n=0;
		do {
			try {
				System.out.println("Inserisci il numero di elementi da dare al vettore: ");
				n=Integer.parseInt(input.nextLine());
				flag=true;
			} catch (NumberFormatException e) {
				System.err.println("Inserisci un numero valido!");
				flag=false;
			}
		} while (!flag);
		int [] vettore = new int[n];
		for (int i=0;i<vettore.length;i++) {
			System.out.print("Inserisci il nunero nella locazione ["+i+"] :");
			vettore[i]=Integer.parseInt(input.nextLine());
			System.out.println("");
		}
		u.mergeSort(vettore, n);
		input.close();

	}

}
