package standalone;

import java.util.ArrayList;
import java.util.List;

public class RicercaUtil {
	double middle;
	int size;
	int lIndex;
	int rIndex;

	public int ricercaBinariaNonRicorsiva(int lista[], int key)
	{
		int lowIndex = 0;
		int highIndex = lista.length-1;

		while (lowIndex<=highIndex) {
			int mid = (lowIndex+highIndex)/2; //approssima per difetto

			if(lista[mid]==key) {
				return mid; //valore trovato nella posizione mid
			}

			else if (lista[mid]<key) {
				lowIndex = mid + 1;
			}
			else {
				highIndex = mid - 1;
			}
		}
		return -1; //non l'ha trovato	
	}

	public int ricercaBinariaRicorsiva(int[] lista, int key, int low, int high){
		int mid;
		mid = (low + high)/2;
		if (!(mid < low)||(high<0))
		{
			return -1; //Valore non trovato
		}
		else if (key < lista[mid])
		{
			return ricercaBinariaRicorsiva(lista, key, low, mid-1);
		}
		else if (key > lista[mid])
		{
			return ricercaBinariaRicorsiva(lista, key, mid+1, high);
		}
		else
		{
			return mid; //Valore trovato nella posizione mid
		}

	}
}


