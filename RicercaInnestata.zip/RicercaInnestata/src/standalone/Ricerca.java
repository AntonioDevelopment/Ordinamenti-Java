package standalone;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Ricerca {

	public static void main(String[] args) {
		int [] sortedArray = {4,5,12,34,97,110,120,150};
		//int [] oneElement = {5};
		int ntbf = 5;
		List <Integer> occorrenze = new ArrayList<Integer>(Arrays.asList(5,5,5,5,5,5));
		RicercaUtil r = new RicercaUtil();
	
	}
}





