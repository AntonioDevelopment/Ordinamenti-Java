package controller;

public class Utility {




	public void mergeSort(int[] vettore,int n) {
		if (vettore.length<=1) {
			return;
		}
		//Dal vettore originale, creiamo 2 vettori chiamati rispettivamente destra e sinistra
		int mid=n/2;
		int [] left= new int [mid]; // Il primo vettore lungo  da 0 fino alla met� arrotondata per difetto in caso di decimale
		int [] right=new int[n-mid];// il secondo avr� lunghezza pari al restante degli elementi ovvero (n - la met�)
		
		// ora popoliamo i 2 neo vettori con gli elementi del vettore originale
		for (int i=0;i<left.length;i++) {
			left[i]=vettore[i];
		}
		for (int i=0;i<right.length;i++) {
			right[i]=vettore[i+mid];
		}
		
		/*
		 *  I vettori "sinistra e destra" verranno a loro volta successivamente spezzettati 
		 *  in altri "sinistra e destra" sempre pi� piccoli finch� non avranno TUTTI lunghezza pari a (vettore.length<=1)
		 */
		mergeSort(left,left.length);
		mergeSort(right,right.length);
		merge(left,right,vettore);
	}
	
	
	
	public void merge(int[] left, int[] right,int[] merged) {
		/*
		 * la lunghezza del vettore merged avra ovviamente una lughezza pari alla lunghezza del suo left+right
		 */
		int indexLeft=0;
		int indexRight=0;
		/*
		 * I vettori left and right saranno sempre ordinati!
		 * si Sfrutta il passaggio per riferimento, ovvero i valori interni al vettore manterranno la loro posizione.
		 */
		System.out.println("Stampa del vettore Left");
		stampaVettore(left);
		System.out.println("Stampa del vettore right");
		stampaVettore(right);		
		for (int i=0;i<merged.length;i++) {
			/*
			 * La condizione sottostante verifica se uno dei due vettori � terminato, infatti sar� TRUE se entrambi
			 * i due vettori non hanno raggiunto la lunghezza massima, appena uno dei due avr� indice pari al suo lenght, allora si entrer� 
			 * nell'altro if che riempira il vettore con gli elementi finali
			 */
			if (indexLeft<left.length && indexRight<right.length) {
				if (left[indexLeft]>right[indexRight]){
					merged[i]=right[indexRight];
					indexRight++;
				} else {
					merged[i]=left[indexLeft];
					indexLeft++;
				}
				/*
				 * Questo else riempie il vettore congli elmenti restanti di LEFT or RIGHT
				 */
			} else {
				if (indexLeft<left.length) {
					merged[i]=left[indexLeft];
					indexLeft++;
				} else if (indexRight<right.length) {
					merged[i]=right[indexRight];
					indexRight++;
				}
			}
		}

		System.out.println("Stampa del vettore final");
		stampaVettore(merged);
	}

	
	
	
	public void stampaVettore(int[] v) {
		for (int i=0;i<v.length;i++) {
			System.out.print(v[i]+ " ");
		}
		System.out.println(" ");
	}


} // Chiusura classe